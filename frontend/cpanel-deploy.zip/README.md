# Place your logo here

Please save your logo image as `logo.png` in this directory.

The logo will be automatically used by the application in:
- Navbar
- Hero section  
- Footer
- Browser favicon

Recommended size: 512x512px or larger (square format preferred)
